clear;
clc;

%given info
bypass_ratio = 5;
M0 = 0.8;
T0 = 236; %K
R = 287; %Jkg-1K-1
k = 1.4;


V0 = M0 * sqrt(k * R * T0);%calculate V0
result = (3 * V0 / bypass_ratio) + V0;%calculate V19

%write to document
file = fopen("q3/v19.tex", "w");
fwrite(file, sprintf("%.3f",result));
fclose(file);