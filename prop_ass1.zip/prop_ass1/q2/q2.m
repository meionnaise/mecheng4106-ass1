clear;
clc;
clf;

%given data
M0 = 0.20:0.01:0.90; %initialise 0.20 < M_0 < 0.90 with step size of 0.01
M_1 = [0.60,  0.80];
k = 1.4;

i = 1;
colours = ["#fda0cc", "#54C7F1"];
for m1 = M_1
    %calculate parts of the expression - T1 / T0
    T1T0 = (1 + (k - 1)/2 * M0.^2) ./ (1 + (k - 1)/2 * m1^2);

    %use T1/T0 to obtain A1/A0
    A1A0 = (M0 ./ m1) .* (T1T0.^(-(k + 1) / (2 * (k - 1))));

    %sub all into eqn
    inlet_drag = (((M0./m1) .*  (sqrt(T1T0)) .* (1 + (k * (m1.^2)))) - (A1A0 + (k .* (M0.^2)))) / 4.5;

    %plot
    plot(M0, inlet_drag, "DisplayName", sprintf("%.2f", m1), "Color", colours(i), "LineWidth", 2)

    i = i + 1;
    hold on
end
leg = legend("color", "#fceff4", "location", "northeast");
leg.Title.String = "$M_1$";
set(leg, "interpreter", "latex")
set(gca,"Color","#fceff4")
xlabel("$M_0$","interpreter","latex")
ylabel("$\phi_{inlet}$", "interpreter", "latex")
exportgraphics(gcf, "q2/q2.png")