clear;
clc;
clf;

%standard day sea level conditions
P_0 = 101325; %Pa
T_0 = 288.15; %K
rho_0 =1.225; %kgm-3
a_std = 340; %ms-1

%known/given
A_1 = 0.4; %m2
M_0 = 0;
k = 1.4;
R = 287.05; %Jkj-1K-1

%% part a
M_1 = 0:0.01:1; %initialise variable M_1 to be 0 < M_1 < 1 with a step size of 0.01
%calculate mass flow rate from derived equation
mdot = (P_0 / sqrt(T_0)) .* sqrt(k / R) .* ((1 + (((k - 1) / 2) .* (M_1 .^ 2))) .^ ((-(k + 1)) / (2 .* (k - 1)))) .* A_1 .* M_1;
plot(mdot, M_1, "color", "#fda0cc", "LineWidth", 2); %plot and export
set(gca,"Color","#fceff4")
xlabel("Mass flow rate, $\dot{m}$ (kgs$^{-1}$)","interpreter","latex")
ylabel("$M_1$", "interpreter", "latex")
exportgraphics(gcf, "q1/q1a.png")
hold on

%% part b
x = 80;
%calculate mach no @ given mass flow rate
y = interp1(mdot, M_1, x);
%plot
plot(x, y, ".", "MarkerSize", 25, "Color", "#fda0cc")
offsetx = 5;
offsety = 0.01 * offsetx;
text(x - offsetx, y - offsety, sprintf("(%.1f, %.3f)", x, y))
exportgraphics(gcf, "q1/q1b.png")
%write value
file = fopen("q1/q1b_mach.tex", "w");
fwrite(file, sprintf("%.3f",y));
fclose(file);

%%part c
M1 = y;
P_1 = P_0 / ((1 + (((k - 1) / 2) .* (y .^ 2))) .^ (k / (k - 1))); %calc P1 from isentropic flow relations
Dadd = P_1 .* A_1 .* (1 + ((k) .* (M1.^2))) - (P_0 .* A_1); %calculate additive drag
file = fopen("q1/q1c_Dadd.tex", "w");
fwrite(file, sprintf("%.3f",Dadd));
fclose(file);
file = fopen("q1/q1c_P1.tex", "w");
fwrite(file, sprintf("%.3f",P_1));
fclose(file);